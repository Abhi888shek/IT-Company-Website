x=("Abhishek")
y=len(x)
slicedString=x[y::-1]
print(slicedString)